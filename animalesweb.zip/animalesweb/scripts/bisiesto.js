function ejecutar() {
    var año1 = parseInt(document.getElementById("año1").value);
    var año2 = parseInt(document.getElementById("año2").value);
    var dic_elementos = document.getElementById("elementos");

    
    dic_elementos.innerHTML = "";

   
    for(let i = año1; i < año2; i++){
        if(i %4 == 0 ){
            dic_elementos.innerHTML += '<p class="bisiesto">' + i + ' es un año bisiesto</p>';

        }else{
            dic_elementos.innerHTML += '<p class="no-bisiesto">' + i + ' no es un año bisiesto</p>';
    }
}
}

function sumar() {
    var año1 = parseInt(document.getElementById("año1").value);
    var año2 = parseInt(document.getElementById("año2").value);

    
    var result = año1 + año2;
    var dic_elementos = document.getElementById("dic_elementos");

    
    dic_elementos.innerHTML = "";

    document.getElementById("elementos").innerText = 
        "El resultado de la suma es " + result;

  
    if ((result % 4 === 0 && result % 100 !== 0) || result % 400 === 0) {
        dic_elementos.innerHTML = '<p class="bisiesto">' + result + ' es un año bisiesto</p>';
    } else {
        dic_elementos.innerHTML = '<p class="no-bisiesto">' + result + ' no es un año bisiesto</p>';
    }
}
