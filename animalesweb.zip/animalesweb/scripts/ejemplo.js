//console.log("Hello World")

function sumar(){

    //Declarar variables
    var valor1 = document.getElementById("valor1").value;
    var valor2 = document.getElementById("valor2").value;

    var result = parseFloat(valor1) + parseFloat(valor2);

    //Colocar un valor interno dentro de p
    document.getElementById("resultado").innerText = 
    "El resultado de la suma es " + result;

}

function restar(){

    var valor1 = document.getElementById("valor1").value;
    var valor2 = document.getElementById("valor2").value;

    var result = parseFloat(valor1) - parseFloat(valor2);

    document.getElementById("resultado").innerText =
    "El resultado de la resta es " + result;
}

function multiplicar(){

    var valor1 = document.getElementById("valor1").value;
    var valor2 = document.getElementById("valor2").value;

    var result = parseFloat(valor1) * parseFloat(valor2);

    document.getElementById("resultado").innerText =
    "El resultado de la multiplicacion es " + result;
}

function division(){

    var valor1 = document.getElementById("valor1").value;
    var valor2 = document.getElementById("valor2").value;

    var result = parseFloat(valor1) / parseFloat(valor2);

    document.getElementById("resultado").innerText =
    "El resultado de la division es " + result;
}
