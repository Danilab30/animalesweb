function ejecutar(){
    
    var valor = document.getElementById("valor").value;
    var dic_elementos = document.getElementById("elementos");


    for(let i = 0; i < valor; i++){
        dic_elementos.innerHTML +='<p class=loop>' + i + '</p>';


    }
}