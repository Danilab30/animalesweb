<?php

class planeta{
    public $id;
    public $nombre;
    public $imagen;
    
}

function getAll(){
    $listaPlanetas = [];
    $path = $_SERVER['DOCUMENT_ROOT'];
    include($path."/animalesweb/php/connection/db.php");
    $query = "SELECT id, nombre, imagen FROM planeta"; 
    $result = $connection->query($query);
    
    if($result->num_rows > 0){
        while($rows = $result->fetch_assoc()){
            $object = new Planeta();
       
            $object->ID = $rows["id"];
            $object->Nombre = $rows["nombre"];
            $object->Imagen = $rows["imagen"];
            $listaPlanetas[] = $object;
        }
    }
    
    return $listaPlanetas;
}
