<?php

class Carro{
    public $id;
    public $modelo;
    public $marca;
    public $color;
}

function getAll(){
    $listaCarros = [];
    $path = $_SERVER['DOCUMENT_ROOT'];
    include($path."/animalesweb/php/connection/db.php");
    $sql = "SELECT id, modelo, marca, color FROM carros";
    $result = $connection->query($sql);
    if($result->num_rows >0){
        while($rows = $result->fetch_assoc()){
        $object = new Carro();
        $object->id = $rows["id"];
        $object->modelo = $rows["modelo"];
        $object->marca = $rows["marca"];
        $object->color = $rows["color"];
        $listaCarro[] = $object;
        }
    }
    return $listaCarro;


}
?>