<?php include("header.php") ?>

<script src="scripts/ejemplo.js"></script>
        <div class="container">
            <h1>Registro de Javascript</h1>
            <h2>Otra cosa</h2>

            <input id="valor1"></input>
            <input type="number" id="valor2"></input>
            <button onclick="sumar()">Sumar</button>
            <button onclick="restar()">Restar</button>
            <button onclick="multiplicar()">Multiplicar</button>
            <button onclick="division()">Division</button>
            <p id ="resultado">Esperando valores...</p>

            

          

        </div>
        <?php include("footer.php") ?>
 