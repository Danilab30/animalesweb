<?php include("header.php") ?>

<script src="scripts/otro-script.js"></script>
<div class="container">
    <h1>Registro de Javascript</h1>
    <h2>Ejemplos con loop</h2>


    <input type="number" id="valor"></input>
    <button onclick="ejecutar()">Ejecutar</button>
    

     <div id="elementos"></div>
</div>
<?php include("footer.php") ?>